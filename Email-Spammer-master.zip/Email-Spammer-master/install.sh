apt-get update -y          # Update
apt-get autoremove         # Auto Remove

sudo "apt-get install pip" # Installing Pip
echo installed pip         # Telling User that installing is done

pip install pysocks        # Installing pysocks
echo "installed pysocks"   # Teling User that installing is done

chmod +x Email-Spam.py     # Giving permission to Email-Spam.py
