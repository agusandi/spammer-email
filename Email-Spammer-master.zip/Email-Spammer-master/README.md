# Email-Spammer
The Ultimate script for spamming email to annoy your friends.
